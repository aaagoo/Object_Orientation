create view tutti_admin(id, nomeutente, password) as
SELECT a.id,
       a.nomeutente,
       a.password
FROM account a
         JOIN amministratore am ON a.id = am.id
ORDER BY a.nomeutente;

alter table tutti_admin
    owner to postgres;

