create function verifica_admin(p_nomeutente character varying, p_password character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM account a
                 JOIN amministratore am ON a.id = am.id
        WHERE a.nomeutente = p_nomeutente
          AND a.password = p_password
    );
END;
$$;

alter function verifica_admin(varchar, varchar) owner to postgres;

