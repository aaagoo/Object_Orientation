create procedure aggiungi_volo(IN p_codice character varying, IN p_compagnia_aerea character varying, IN p_aeroporto_origine character varying, IN p_aeroporto_destinazione character varying, IN p_data_partenza date, IN p_orario time without time zone, IN p_tipo_volo character varying)
    language plpgsql
as
$$
BEGIN
    -- Verifica che il tipo_volo sia valido
    IF p_tipo_volo NOT IN ('ARRIVO', 'PARTENZA') THEN
        RAISE EXCEPTION 'Il tipo volo deve essere ARRIVO o PARTENZA';
    END IF;

    -- Verifica che la data non sia nel passato
    IF p_data_partenza < CURRENT_DATE THEN
        RAISE EXCEPTION 'Non è possibile inserire voli con data nel passato';
    END IF;

    -- Verifica che se la data è oggi, l'orario non sia nel passato
    IF p_data_partenza = CURRENT_DATE AND p_orario < CURRENT_TIME THEN
        RAISE EXCEPTION 'Non è possibile inserire voli con orario nel passato';
    END IF;

    -- Inserimento del nuovo volo
    INSERT INTO volo (
        codice,
        compagnia_aerea,
        aeroporto_origine,
        aeroporto_destinazione,
        data_partenza,
        orario,
        tipo_volo,
        stato,
        ritardo
    ) VALUES (
                 p_codice,
                 p_compagnia_aerea,
                 p_aeroporto_origine,
                 p_aeroporto_destinazione,
                 p_data_partenza,
                 p_orario,
                 p_tipo_volo,
                 'PROGRAMMATO',
                 0
             );
END;
$$;

alter procedure aggiungi_volo(varchar, varchar, varchar, varchar, date, time, varchar) owner to postgres;

