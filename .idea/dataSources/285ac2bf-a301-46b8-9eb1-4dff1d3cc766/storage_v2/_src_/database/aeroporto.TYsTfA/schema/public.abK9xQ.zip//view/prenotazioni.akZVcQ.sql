create view prenotazioni
            (numero_biglietto, posto_assegnato, stato_prenotazione, nome_passeggero, cognome_passeggero, codice_volo,
             username_prenotazione, compagnia_aerea, aeroporto_origine, aeroporto_destinazione, data_partenza, orario,
             ritardo, stato_volo, tipo_volo)
as
SELECT p.numero_biglietto,
       p.posto_assegnato,
       p.stato AS stato_prenotazione,
       p.nome_passeggero,
       p.cognome_passeggero,
       p.codice_volo,
       p.username_prenotazione,
       v.compagnia_aerea,
       v.aeroporto_origine,
       v.aeroporto_destinazione,
       v.data_partenza,
       v.orario,
       v.ritardo,
       v.stato AS stato_volo,
       v.tipo_volo
FROM prenotazione p
         JOIN volo v ON p.codice_volo::text = v.codice::text
         JOIN account a ON p.username_prenotazione::text = a.nomeutente::text;

alter table prenotazioni
    owner to postgres;

