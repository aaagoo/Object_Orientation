create view voli_in_arrivo
            (codice, compagnia_aerea, aeroporto_origine, aeroporto_destinazione, data_partenza, orario, ritardo, stato,
             tipo_volo) as
SELECT codice,
       compagnia_aerea,
       aeroporto_origine,
       aeroporto_destinazione,
       data_partenza,
       orario,
       ritardo,
       stato,
       tipo_volo
FROM volo
WHERE tipo_volo::text = 'ARRIVO'::text
  AND aeroporto_destinazione::text = 'Napoli'::text;

alter table voli_in_arrivo
    owner to postgres;

