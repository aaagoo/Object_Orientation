create function genera_numero_biglietto() returns character varying
    language plpgsql
as
$$
DECLARE
    ultimo_numero INTEGER;
BEGIN

    SELECT MAX(CAST(SUBSTRING(numero_biglietto FROM 4) AS INTEGER))
    INTO ultimo_numero
    FROM prenotazione
    WHERE numero_biglietto LIKE 'PRE%';

    IF ultimo_numero IS NULL THEN
        ultimo_numero := 0;
    END IF;

    ultimo_numero := ultimo_numero + 1;

    RETURN 'PRE' || LPAD(ultimo_numero::TEXT, 6, '0');
END;
$$;

alter function genera_numero_biglietto() owner to postgres;

