create view voli_in_partenza
            (codice, compagnia_aerea, aeroporto_origine, aeroporto_destinazione, data_partenza, orario, ritardo, stato,
             tipo_volo, numero_gate)
as
SELECT v.codice,
       v.compagnia_aerea,
       v.aeroporto_origine,
       v.aeroporto_destinazione,
       v.data_partenza,
       v.orario,
       v.ritardo,
       v.stato,
       v.tipo_volo,
       g.numero_gate
FROM volo v
         LEFT JOIN gate g ON v.codice::text = g.codice_volo::text
WHERE v.tipo_volo::text = 'PARTENZA'::text
  AND v.aeroporto_origine::text = 'Napoli'::text;

alter table voli_in_partenza
    owner to postgres;

