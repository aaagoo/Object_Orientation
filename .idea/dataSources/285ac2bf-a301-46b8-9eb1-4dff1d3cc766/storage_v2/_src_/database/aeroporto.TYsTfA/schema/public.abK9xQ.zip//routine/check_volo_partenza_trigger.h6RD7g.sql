create function check_volo_partenza_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.codice_volo IS NOT NULL THEN
        IF NOT EXISTS (
            SELECT 1
            FROM volo v
            WHERE v.codice = NEW.codice_volo
              AND v.tipo_volo = 'PARTENZA'
        ) THEN
            RAISE EXCEPTION 'Il gate può essere assegnato solo a voli in partenza';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_volo_partenza_trigger() owner to postgres;

