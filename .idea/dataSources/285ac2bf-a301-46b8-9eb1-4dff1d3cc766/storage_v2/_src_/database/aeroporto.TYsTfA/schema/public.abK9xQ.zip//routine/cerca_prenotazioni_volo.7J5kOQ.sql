create function cerca_prenotazioni_volo(p_codice_volo character varying)
    returns TABLE(numero_biglietto character varying, posto_assegnato character varying, stato_prenotazione stato_prenotazione, nome_passeggero character varying, cognome_passeggero character varying, compagnia_aerea character varying, aeroporto_origine character varying, aeroporto_destinazione character varying, data_partenza date, orario time without time zone, ritardo integer, stato_volo stato_volo, numero_gate integer)
    language plpgsql
as
$$
BEGIN

    -- Verifica che il volo esista
    IF NOT EXISTS (SELECT 1 FROM volo WHERE codice = p_codice_volo) THEN
        RAISE EXCEPTION 'Volo con codice % non trovato', p_codice_volo;
    END IF;

    RETURN QUERY
        SELECT
            p.numero_biglietto,
            p.posto_assegnato,
            p.stato,
            p.nome_passeggero,
            p.cognome_passeggero,
            v.compagnia_aerea,
            v.aeroporto_origine,
            v.aeroporto_destinazione,
            v.data_partenza,
            v.orario,
            v.ritardo,
            v.stato,
            g.numero_gate
        FROM prenotazione p
                 JOIN volo v ON p.codice_volo = v.codice
                 LEFT JOIN gate g ON v.codice = g.codice_volo
        WHERE p.codice_volo = p_codice_volo
        ORDER BY p.posto_assegnato;
END;
$$;

alter function cerca_prenotazioni_volo(varchar) owner to postgres;

