create function verifica_utente(p_nomeutente character varying, p_password character varying) returns boolean
    language plpgsql
as
$$
BEGIN
    RETURN EXISTS (
        SELECT 1
        FROM account a
                 JOIN utente u ON a.id = u.id
        WHERE a.nomeutente = p_nomeutente
          AND a.password = p_password
    );
END;
$$;

alter function verifica_utente(varchar, varchar) owner to postgres;

