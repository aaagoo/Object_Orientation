create procedure modifica_admin(IN p_nomeutente character varying, IN p_nuova_password character varying)
    language plpgsql
as
$$
DECLARE
    v_admin_id INTEGER;
BEGIN
    -- Verifica che l'account sia effettivamente un amministratore
    SELECT a.id INTO v_admin_id
    FROM account a
             JOIN amministratore am ON a.id = am.id
    WHERE a.nomeutente = p_nomeutente;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'L''account % non è un amministratore', p_nomeutente;
    END IF;

    -- Aggiorna la password
    UPDATE account
    SET password = p_nuova_password
    WHERE id = v_admin_id;

EXCEPTION
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante la modifica della password: %', SQLERRM;
END;
$$;

alter procedure modifica_admin(varchar, varchar) owner to postgres;

