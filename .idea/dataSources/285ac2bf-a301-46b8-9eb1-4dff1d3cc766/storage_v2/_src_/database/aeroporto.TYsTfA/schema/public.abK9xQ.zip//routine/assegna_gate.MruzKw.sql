create procedure assegna_gate(IN p_codice_volo character varying, IN p_numero_gate integer)
    language plpgsql
as
$$
DECLARE
    v_tipo_volo VARCHAR(10);
    v_stato_volo stato_volo;
BEGIN
    -- Verifica che il volo esista e ottieni informazioni
    SELECT tipo_volo, stato
    INTO v_tipo_volo, v_stato_volo
    FROM volo
    WHERE codice = p_codice_volo;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Volo % non trovato', p_codice_volo;
    END IF;

    -- Verifica che il volo sia in partenza
    IF v_tipo_volo != 'PARTENZA' THEN
        RAISE EXCEPTION 'I gate possono essere assegnati solo ai voli in partenza';
    END IF;

    -- Verifica che il volo non sia già partito o cancellato
    IF v_stato_volo IN ('DECOLLATO', 'ATTERRATO', 'CANCELLATO') THEN
        RAISE EXCEPTION 'Non è possibile assegnare un gate a un volo %', v_stato_volo;
    END IF;

    -- Verifica che il gate non sia già assegnato a questo volo
    DELETE FROM gate WHERE codice_volo = p_codice_volo;

    -- Inserisci la nuova assegnazione
    INSERT INTO gate (numero_gate, codice_volo)
    VALUES (p_numero_gate, p_codice_volo);

EXCEPTION
    WHEN check_violation THEN
        RAISE EXCEPTION 'Il numero del gate deve essere positivo';
    WHEN unique_violation THEN
        RAISE EXCEPTION 'Il gate % è già assegnato', p_numero_gate;
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante l''assegnazione del gate: %', SQLERRM;
END;
$$;

alter procedure assegna_gate(varchar, integer) owner to postgres;

