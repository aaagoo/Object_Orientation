create procedure assegna_gate(IN p_codice_volo character varying, IN p_numero_gate integer)
    language plpgsql
as
$$
BEGIN
    -- Verifica che il volo esista e sia un volo in partenza
    IF NOT EXISTS (
        SELECT 1
        FROM volo_partenza
        WHERE codice = p_codice_volo
    ) THEN
        RAISE EXCEPTION 'Il volo % non esiste o non è un volo in partenza', p_codice_volo;
    END IF;

    -- Verifica che il volo non sia già partito o cancellato
    IF EXISTS (
        SELECT 1
        FROM volo
        WHERE codice = p_codice_volo
          AND stato IN ('DECOLLATO', 'ATTERRATO', 'CANCELLATO')
    ) THEN
        RAISE EXCEPTION 'Non è possibile assegnare un gate a un volo già partito o cancellato';
    END IF;

    -- Verifica che il numero del gate non sia già in uso da un altro volo
    IF EXISTS (
        SELECT 1
        FROM gate
        WHERE numero_gate = p_numero_gate
          AND codice_volo != p_codice_volo
    ) THEN
        RAISE EXCEPTION 'Il gate % è già assegnato ad un altro volo', p_numero_gate;
    END IF;

    -- Inserisci o aggiorna l'assegnazione del gate
    INSERT INTO gate (codice_volo, numero_gate)
    VALUES (p_codice_volo, p_numero_gate)
    ON CONFLICT (codice_volo) DO UPDATE
        SET numero_gate = p_numero_gate;

    -- Aggiorna il numero_gate nella tabella volo_partenza
    UPDATE volo_partenza
    SET numero_gate = p_numero_gate
    WHERE codice = p_codice_volo;

EXCEPTION
    WHEN check_violation THEN
        RAISE EXCEPTION 'Il numero del gate deve essere positivo';
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante l''assegnazione del gate: %', SQLERRM;
END;
$$;

alter procedure assegna_gate(varchar, integer) owner to postgres;

