create function cerca_prenotazioni_passeggero(p_nome_passeggero character varying, p_cognome_passeggero character varying)
    returns TABLE(numero_biglietto character varying, posto_assegnato character varying, stato stato_prenotazione, nome_passeggero character varying, cognome_passeggero character varying, codice_volo character varying, compagnia_aerea character varying, aeroporto_origine character varying, aeroporto_destinazione character varying, data_partenza date, orario time without time zone, ritardo integer, stato_volo stato_volo, numero_gate integer, username_prenotazione character varying)
    language plpgsql
as
$$
BEGIN
    -- [resto del codice uguale]
    RETURN QUERY
        SELECT
            p.numero_biglietto,
            p.posto_assegnato,
            p.stato,
            p.nome_passeggero,    -- Aggiunto
            p.cognome_passeggero, -- Aggiunto
            p.codice_volo,
            v.compagnia_aerea,
            v.aeroporto_origine,
            v.aeroporto_destinazione,
            v.data_partenza,
            v.orario,
            v.ritardo,
            v.stato,
            g.numero_gate,
            p.username_prenotazione
        FROM prenotazione p
                 JOIN volo v ON p.codice_volo = v.codice
                 LEFT JOIN gate g ON v.codice = g.codice_volo
        WHERE p.nome_passeggero = p_nome_passeggero
          AND p.cognome_passeggero = p_cognome_passeggero
        ORDER BY v.data_partenza, v.orario;
END;
$$;

alter function cerca_prenotazioni_passeggero(varchar, varchar) owner to postgres;

