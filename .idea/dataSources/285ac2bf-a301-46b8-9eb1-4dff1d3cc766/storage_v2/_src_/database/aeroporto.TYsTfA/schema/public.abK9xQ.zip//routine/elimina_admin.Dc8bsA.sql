create procedure elimina_admin(IN p_nomeutente character varying)
    language plpgsql
as
$$
DECLARE
    admin_id INTEGER;
BEGIN

    -- Verifica che l'amministratore da eliminare esista
    SELECT a.id INTO admin_id
    FROM account a
             JOIN amministratore am ON a.id = am.id
    WHERE a.nomeutente = p_nomeutente;

    -- Elimina il record amministratore
    DELETE FROM amministratore
    WHERE id = admin_id;

    -- Elimina l'account
    DELETE FROM account
    WHERE id = admin_id;

EXCEPTION
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante l''eliminazione dell''amministratore: %', SQLERRM;
END;
$$;

alter procedure elimina_admin(varchar) owner to postgres;

