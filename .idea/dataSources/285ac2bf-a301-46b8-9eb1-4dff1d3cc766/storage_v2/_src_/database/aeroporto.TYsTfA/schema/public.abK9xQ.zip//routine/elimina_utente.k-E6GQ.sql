create procedure elimina_utente(IN p_nomeutente character varying)
    language plpgsql
as
$$
DECLARE
    user_id INTEGER;
BEGIN

    -- Verifica che l'account da eliminare sia effettivamente un utente
    SELECT a.id INTO user_id
    FROM account a
             JOIN utente u ON a.id = u.id
    WHERE a.nomeutente = p_nomeutente;

    -- Prima elimina tutte le prenotazioni dell'utente
    DELETE FROM prenotazione
    WHERE username_prenotazione = p_nomeutente;

    -- Poi elimina il record utente
    DELETE FROM utente
    WHERE id = user_id;

    -- Infine elimina l'account
    DELETE FROM account
    WHERE id = user_id;

EXCEPTION
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante l''eliminazione dell''utente: %', SQLERRM;
END;
$$;

alter procedure elimina_utente(varchar) owner to postgres;

