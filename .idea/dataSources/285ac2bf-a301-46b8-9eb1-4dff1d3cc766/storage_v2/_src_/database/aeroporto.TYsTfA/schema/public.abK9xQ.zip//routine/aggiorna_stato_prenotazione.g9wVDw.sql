create procedure aggiorna_stato_prenotazione(IN p_numero_biglietto character varying, IN p_nuovo_stato stato_prenotazione)
    language plpgsql
as
$$
BEGIN

    -- Verifica se la prenotazione esiste
    IF NOT EXISTS (
        SELECT 1 FROM prenotazione
        WHERE numero_biglietto = p_numero_biglietto
    ) THEN
        RAISE EXCEPTION 'Prenotazione con numero biglietto % non trovata', p_numero_biglietto;
    END IF;

    -- Aggiorna lo stato della prenotazione
    UPDATE prenotazione
    SET stato = p_nuovo_stato
    WHERE numero_biglietto = p_numero_biglietto;
END;
$$;

alter procedure aggiorna_stato_prenotazione(varchar, stato_prenotazione) owner to postgres;

