create function check_tipo_volo() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.tipo = 'PARTENZA' AND TG_TABLE_NAME <> 'volo_partenza' THEN
        RAISE EXCEPTION 'I voli di tipo PARTENZA devono essere inseriti nella tabella volo_partenza';
    ELSIF NEW.tipo = 'ARRIVO' AND TG_TABLE_NAME <> 'volo_arrivo' THEN
        RAISE EXCEPTION 'I voli di tipo ARRIVO devono essere inseriti nella tabella volo_arrivo';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_tipo_volo() owner to postgres;

