create procedure elimina_prenotazione(IN p_numero_biglietto character varying)
    language plpgsql
as
$$
BEGIN
    -- Elimina la prenotazione
    DELETE FROM prenotazione
    WHERE numero_biglietto = p_numero_biglietto;
END;
$$;

alter procedure elimina_prenotazione(varchar) owner to postgres;

