create procedure modifica_utente(IN p_nomeutente character varying, IN p_nuova_password character varying, IN p_nuovo_nome character varying, IN p_nuovo_cognome character varying)
    language plpgsql
as
$$
DECLARE
    v_user_id INTEGER;
BEGIN
    -- Ottieni l'ID dell'utente
    SELECT id INTO v_user_id
    FROM account
    WHERE nomeutente = p_nomeutente;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Utente % non trovato', p_nomeutente;
    END IF;

    -- Aggiorna la password dell'account
    UPDATE account
    SET password = p_nuova_password
    WHERE id = v_user_id;

    -- Aggiorna i dati dell'utente
    UPDATE utente
    SET nome = p_nuovo_nome,
        cognome = p_nuovo_cognome
    WHERE id = v_user_id;

EXCEPTION
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante la modifica dell''utente: %', SQLERRM;
END;
$$;

alter procedure modifica_utente(varchar, varchar, varchar, varchar) owner to postgres;

