create procedure aggiorna_stato_volo(IN p_codice_volo character varying, IN p_nuovo_stato stato_volo, IN p_ritardo integer)
    language plpgsql
as
$$
BEGIN
    -- Verifica se il volo esiste
    IF NOT EXISTS (
        SELECT 1 FROM volo
        WHERE codice = p_codice_volo
    ) THEN
        RAISE EXCEPTION 'Volo con codice % non trovato', p_codice_volo;
    END IF;

    -- Verifica che il ritardo non sia negativo
    IF p_ritardo < 0 THEN
        RAISE EXCEPTION 'Il ritardo non può essere negativo';
    END IF;

    -- Aggiorna lo stato e il ritardo del volo
    UPDATE volo
    SET stato = p_nuovo_stato,
        ritardo = p_ritardo
    WHERE codice = p_codice_volo;

    -- Se il ritardo è maggiore di 0, imposta automaticamente lo stato a IN_RITARDO
    IF p_ritardo > 0 AND p_nuovo_stato = 'PROGRAMMATO' THEN
        UPDATE volo
        SET stato = 'IN_RITARDO'::stato_volo
        WHERE codice = p_codice_volo;
    END IF;

END;
$$;

alter procedure aggiorna_stato_volo(varchar, stato_volo, integer) owner to postgres;

