create view tutti_utenti(id, nomeutente, password, nome, cognome) as
SELECT a.id,
       a.nomeutente,
       a.password,
       u.nome,
       u.cognome
FROM account a
         JOIN utente u ON a.id = u.id
ORDER BY u.cognome, u.nome;

alter table tutti_utenti
    owner to postgres;

