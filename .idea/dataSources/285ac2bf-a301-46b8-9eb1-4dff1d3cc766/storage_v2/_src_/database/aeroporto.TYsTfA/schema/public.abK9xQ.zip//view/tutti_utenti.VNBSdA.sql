create view tutti_utenti(nomeutente, password, nome, cognome) as
SELECT a.nomeutente,
       a.password,
       u.nome,
       u.cognome
FROM account a
         JOIN utente u ON a.id = u.id
ORDER BY u.cognome, u.nome;

alter table tutti_utenti
    owner to postgres;

