create procedure aggiungi_volo(IN p_codice character varying, IN p_compagnia_aerea character varying, IN p_aeroporto_origine character varying, IN p_aeroporto_destinazione character varying, IN p_data_partenza date, IN p_orario time without time zone, IN p_tipo_volo tipo_volo, IN p_ritardo integer, IN p_stato stato_volo)
    language plpgsql
as
$$
BEGIN
    -- Verifica che il ritardo non sia negativo
    IF p_ritardo < 0 THEN
        RAISE EXCEPTION 'Il ritardo non può essere negativo';
    END IF;

    -- Verifica che la data non sia nel passato
    IF p_data_partenza < CURRENT_DATE THEN
        RAISE EXCEPTION 'Non è possibile inserire voli con data nel passato';
    END IF;

    -- Verifica che se la data è oggi, l'orario non sia nel passato
    IF p_data_partenza = CURRENT_DATE AND p_orario < CURRENT_TIME THEN
        RAISE EXCEPTION 'Non è possibile inserire voli con orario nel passato';
    END IF;

    -- Inserisci il volo nella tabella appropriata
    IF p_tipo_volo = 'PARTENZA' THEN
        INSERT INTO volo_partenza (
            codice, compagnia_aerea, aeroporto_origine, aeroporto_destinazione,
            data_partenza, orario, ritardo, stato, tipo
        ) VALUES (
                     p_codice, p_compagnia_aerea, p_aeroporto_origine, p_aeroporto_destinazione,
                     p_data_partenza, p_orario, p_ritardo, p_stato, p_tipo_volo
                 );
    ELSIF p_tipo_volo = 'ARRIVO' THEN
        INSERT INTO volo_arrivo (
            codice, compagnia_aerea, aeroporto_origine, aeroporto_destinazione,
            data_partenza, orario, ritardo, stato, tipo
        ) VALUES (
                     p_codice, p_compagnia_aerea, p_aeroporto_origine, p_aeroporto_destinazione,
                     p_data_partenza, p_orario, p_ritardo, p_stato, p_tipo_volo
                 );
    END IF;
END;
$$;

alter procedure aggiungi_volo(varchar, varchar, varchar, varchar, date, time, tipo_volo, integer, stato_volo) owner to postgres;

