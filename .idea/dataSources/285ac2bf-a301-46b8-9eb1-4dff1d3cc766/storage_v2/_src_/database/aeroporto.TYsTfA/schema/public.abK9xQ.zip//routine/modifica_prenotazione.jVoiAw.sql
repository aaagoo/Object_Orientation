create procedure modifica_prenotazione(IN p_nomeutente character varying, IN p_codice_volo_vecchio character varying, IN p_codice_volo_nuovo character varying, IN p_nuovo_nome character varying, IN p_nuovo_cognome character varying)
    language plpgsql
as
$$
DECLARE
    v_numero_biglietto VARCHAR(20);
    v_stato_volo stato_volo;
BEGIN
    -- Verifica che la prenotazione esista
    SELECT numero_biglietto INTO v_numero_biglietto
    FROM prenotazione
    WHERE username_prenotazione = p_nomeutente
      AND codice_volo = p_codice_volo_vecchio;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Nessuna prenotazione trovata per l''utente % sul volo %',
            p_nomeutente, p_codice_volo_vecchio;
    END IF;

    -- Verifica che il nuovo volo esista e non sia già partito/cancellato
    SELECT stato INTO v_stato_volo
    FROM volo
    WHERE codice = p_codice_volo_nuovo;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Il volo % non esiste', p_codice_volo_nuovo;
    END IF;

    IF v_stato_volo IN ('DECOLLATO', 'CANCELLATO') THEN
        RAISE EXCEPTION 'Non è possibile prenotare un volo %', v_stato_volo;
    END IF;

    -- Elimina la vecchia prenotazione
    DELETE FROM prenotazione
    WHERE numero_biglietto = v_numero_biglietto;

    -- Crea la nuova prenotazione
    INSERT INTO prenotazione (
        numero_biglietto,
        posto_assegnato,
        stato,
        nome_passeggero,
        cognome_passeggero,
        codice_volo,
        username_prenotazione
    ) VALUES (
                 genera_numero_biglietto(),
                 genera_posto_casuale(p_codice_volo_nuovo),
                 'CONFERMATA',
                 p_nuovo_nome,
                 p_nuovo_cognome,
                 p_codice_volo_nuovo,
                 p_nomeutente
             );

EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'Il passeggero ha già una prenotazione per questo volo';
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante la modifica della prenotazione: %', SQLERRM;
END;
$$;

alter procedure modifica_prenotazione(varchar, varchar, varchar, varchar, varchar) owner to postgres;

