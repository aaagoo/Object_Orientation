create function genera_posto_casuale(p_codice_volo character varying) returns character varying
    language plpgsql
as
$$
DECLARE
    posto VARCHAR(4);
    occupato BOOLEAN;
BEGIN
    LOOP
        -- Genera un posto casuale (fila 1-30, lettera A-F)
        posto := LPAD(FLOOR(RANDOM() * 30 + 1)::TEXT, 2, '0') ||
                 CHR(FLOOR(RANDOM() * 6 + 65)::INTEGER);

        -- Verifica se il posto è già occupato
        SELECT EXISTS(
            SELECT 1
            FROM prenotazione
            WHERE codice_volo = p_codice_volo
              AND posto_assegnato = posto
        ) INTO occupato;

        EXIT WHEN NOT occupato;
    END LOOP;

    RETURN posto;
END;
$$;

alter function genera_posto_casuale(varchar) owner to postgres;

