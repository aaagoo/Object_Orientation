create function pulisci_gate_trigger() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.stato IN ('DECOLLATO', 'CANCELLATO') THEN
        DELETE FROM gate WHERE codice_volo = NEW.codice;
    END IF;
    RETURN NEW;
END;
$$;

alter function pulisci_gate_trigger() owner to postgres;

