create view tutti_voli
            (codice, compagnia_aerea, aeroporto_origine, aeroporto_destinazione, data_partenza, orario, ritardo, stato,
             tipo, numero_gate)
as
SELECT volo_partenza.codice,
       volo_partenza.compagnia_aerea,
       volo_partenza.aeroporto_origine,
       volo_partenza.aeroporto_destinazione,
       volo_partenza.data_partenza,
       volo_partenza.orario,
       volo_partenza.ritardo,
       volo_partenza.stato,
       volo_partenza.tipo,
       volo_partenza.numero_gate
FROM volo_partenza
UNION ALL
SELECT volo_arrivo.codice,
       volo_arrivo.compagnia_aerea,
       volo_arrivo.aeroporto_origine,
       volo_arrivo.aeroporto_destinazione,
       volo_arrivo.data_partenza,
       volo_arrivo.orario,
       volo_arrivo.ritardo,
       volo_arrivo.stato,
       volo_arrivo.tipo,
       NULL::integer AS numero_gate
FROM volo_arrivo;

alter table tutti_voli
    owner to postgres;

