create procedure crea_prenotazione(IN p_nomeutente character varying, IN p_nome_passeggero character varying, IN p_cognome_passeggero character varying, IN p_codice_volo character varying)
    language plpgsql
as
$$
DECLARE
    v_stato_volo stato_volo;
BEGIN
    -- Ottiene lo stato del volo
    SELECT stato INTO v_stato_volo
    FROM volo
    WHERE codice = p_codice_volo;

    -- Verifica che il volo non sia già partito o cancellato
    IF v_stato_volo IN ('DECOLLATO', 'CANCELLATO') THEN
        RAISE EXCEPTION 'Non è possibile prenotare un volo %', v_stato_volo;
    END IF;

    INSERT INTO prenotazione (
        numero_biglietto,
        posto_assegnato,
        stato,
        nome_passeggero,
        cognome_passeggero,
        codice_volo,
        username_prenotazione
    ) VALUES (
                 genera_numero_biglietto(),
                 genera_posto_casuale(p_codice_volo),
                 'CONFERMATA',
                 p_nome_passeggero,
                 p_cognome_passeggero,
                 p_codice_volo,
                 p_nomeutente
             );
END;
$$;

alter procedure crea_prenotazione(varchar, varchar, varchar, varchar) owner to postgres;

