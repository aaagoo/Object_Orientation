create procedure crea_account_admin(IN p_nomeutente character varying, IN p_password character varying)
    language plpgsql
as
$$
DECLARE
    v_account_id INTEGER;
BEGIN
    -- Verifica che il nome utente non esista già
    IF EXISTS (
        SELECT 1
        FROM account
        WHERE nomeutente = p_nomeutente
    ) THEN
        RAISE EXCEPTION 'Il nome utente % è già in uso', p_nomeutente;
    END IF;

    -- Inserisci il nuovo account e ottieni l'ID generato
    INSERT INTO account (nomeutente, password)
    VALUES (p_nomeutente, p_password)
    RETURNING id INTO v_account_id;

    -- Inserisci il record amministratore
    INSERT INTO amministratore (id)
    VALUES (v_account_id);

EXCEPTION
    WHEN others THEN
        RAISE EXCEPTION 'Errore durante la creazione dell''account amministratore: %', SQLERRM;
END;
$$;

alter procedure crea_account_admin(varchar, varchar) owner to postgres;

