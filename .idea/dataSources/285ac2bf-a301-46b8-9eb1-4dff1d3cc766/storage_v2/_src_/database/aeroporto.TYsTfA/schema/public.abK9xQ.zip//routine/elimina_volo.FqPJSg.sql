create procedure elimina_volo(IN p_codice_volo character varying)
    language plpgsql
as
$$
BEGIN

    -- Verifica che il volo esista
    IF NOT EXISTS (SELECT 1 FROM volo WHERE codice = p_codice_volo) THEN
        RAISE EXCEPTION 'Volo con codice % non trovato', p_codice_volo;
    END IF;

    -- Prima elimina eventuali riferimenti nella tabella gate
    DELETE FROM gate
    WHERE codice_volo = p_codice_volo;

    -- Poi elimina eventuali prenotazioni associate
    DELETE FROM prenotazione
    WHERE codice_volo = p_codice_volo;

    -- Infine elimina il volo
    DELETE FROM volo
    WHERE codice = p_codice_volo;

END;
$$;

alter procedure elimina_volo(varchar) owner to postgres;

